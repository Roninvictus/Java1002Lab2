fun encrypt(initialInfo: String, shift: Int): String {
    val letters = "abcdefghijklmnopqrstuvwxyz"
    var encryptInfo = ""

    for (char in initialInfo) {
        if(char.isLetter()) {
            // use index to add shift value to current letter
            val shiftedIndex = (letters.indexOf(char.lowercaseChar()) + shift) % 26
            val shiftedChar = letters[shiftedIndex]

            // for uppercase
            encryptInfo += if(char.isUpperCase()) shiftedChar.uppercaseChar() else shiftedChar
        } else {
            // add to string if character isn't a letter
            encryptInfo += char
        }
    }
    return encryptInfo
}

fun arrayAvg(array: Array<Double>): Double {
    var sum = 0.0
    // loop through array to get total sum of values
    for (value in array) {
        sum += value
    }

    // to get average number
    return sum / array.size
}

fun arrayContains(array: Array<String>, searchedValue: Any): Boolean {

    for (element in array) {
        // If value in array is same as searched value, return 'true'
        if (element == searchedValue)
            return true
    }
    return false
}

inline fun <reified T> reverse(initialArray: Array<T>): Array<T> {
    // store the reverse sequence of the integer list
    val reversedList = mutableListOf<T>()

    // adding the reverse sequence of array elements to a list
    for (i in initialArray.size - 1 downTo 0) {
        reversedList.add(initialArray[i])
    }

    // to revert list to Array
    return reversedList.toTypedArray()
}

fun main() {
    print("Enter the operation you want to perform (encrypt, arrayAvg, arrayContains, reverse): ")
    val operation = readLine()!!

    when(operation) {
        "encrypt" -> {
            print("Input text to be encrypted: ")
            val initialInfo = readLine()!!
            print("Input shift value: ")
            val shift = readLine()!!.toInt()
            val encryptedText = encrypt(initialInfo, shift)
            println("Encrypted message is: $encryptedText")
        }
        "arrayAvg" -> {
            print("Input the array elements separated by commas: ")
            val values = readLine()!!.split(",").map { it.trim().toDouble() }.toTypedArray()
            val average = arrayAvg(values)
            println("Average of values is = $average")
        }
        "arrayContains" -> {
            print("Input the array elements separated by commas: ")
            val array = readLine()!!.split(",").map { it.trim() }.toTypedArray()
            print("Enter the value to search for: ")
            val searchedValue = readLine()!!
            val contains = arrayContains(array, searchedValue)
            println("The array contains $searchedValue: $contains")
        }
        "reverse" -> {
            print("Input the array elements separated by commas: ")
            val array = readLine()!!.split(",").map { it.trim() }.toTypedArray()
            val reversedArray = reverse(array)
            println("Reversed array: ${reversedArray.contentToString()}")
        }
    }
}
